package com.br.cassio.cassiobookstore


import android.content.Intent
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import com.br.cassio.cassiobookstore.mock.MY_MOCKS_BOOKS_LIST
import com.br.cassio.cassiobookstore.repository.retrofit.bookapi.ApiInterface
import com.br.cassio.cassiobookstore.repository.retrofit.bookapi.BooksApi
import net.vidageek.mirror.dsl.Mirror
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException


/**
 * (by Cassio Ribeiro)
 * Testing especific devices and orientation changes
 * (layout changes) by detecting its kind
 * --------------------------
 */
@RunWith(AndroidJUnit4::class)
class ClickMasterDetailTest {

    lateinit var server: MockWebServer

    @get:Rule
    var itemListActivity: ActivityTestRule<ItemListActivity> =
        ActivityTestRule(ItemListActivity::class.java)

    @Before
    @Throws(Exception::class)
    fun setUp() {
        server = MockWebServer()
        server.start(8080)
        setupServerUrl()
    }

    @After
    @Throws(IOException::class)
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun whenResultIsOk_shouldDisplayListWithUsers() {
        server.enqueue(MockResponse().setResponseCode(200).setBody(MY_MOCKS_BOOKS_LIST))
        itemListActivity.launchActivity(Intent())
    }

    private fun setupServerUrl() {
        val url = server.url("/").toString()
        val interceptor = HttpLoggingInterceptor()
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        val client = OkHttpClient.Builder().addInterceptor(interceptor).build()
        val booksApi: BooksApi = BooksApi.getInstance()
        val api = Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create(BooksApi.GSON))
            .client(client)
            .build()
            .create(ApiInterface::class.java)
        setField(booksApi, "api", api)
    }

    private fun setField(target: Any, fieldName: String, value: Any) {
        Mirror()
            .on(target)
            .set()
            .field(fieldName)
            .withValue(value)
    }
}