# exampleBookStore
A simple example to demonstrate part of my knowledge
